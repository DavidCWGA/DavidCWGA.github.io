# -*- coding: utf-8 -*-

import sys
import requests
import json
import re
import os
import time
from typing import List, Optional
from bs4 import BeautifulSoup
from urllib.parse import urlparse, parse_qs
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

# Addon specific objects
ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
ADDON_URL = sys.argv[0]

# Cache settings
CACHE_DURATION = 10 * 60  # 10 minutes in seconds
ADDON_DATA_PATH = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON.getAddonInfo('id')}/")
CACHE_FILE = os.path.join(ADDON_DATA_PATH, "cache.json")

# --- Cache Helper Functions ---

def ensure_addon_data_dir():
    """Ensures the addon_data directory exists."""
    if not os.path.exists(ADDON_DATA_PATH):
        try:
            os.makedirs(ADDON_DATA_PATH)
            xbmc.log(f"BBC News Live: Created addon_data directory: {ADDON_DATA_PATH}", level=xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"BBC News Live: Error creating addon_data directory: {e}", level=xbmc.LOGERROR)

def load_cache() -> Optional[List[dict]]:
    """Loads stream items from cache if valid and not expired."""
    ensure_addon_data_dir()
    if not os.path.exists(CACHE_FILE):
        xbmc.log("BBC News Live: Cache file not found.", level=xbmc.LOGDEBUG)
        return None
    try:
        with open(CACHE_FILE, 'r') as f:
            cached_data = json.load(f)
        
        if time.time() < cached_data.get('expires_at', 0):
            xbmc.log("BBC News Live: Using cached stream list.", level=xbmc.LOGDEBUG)
            return cached_data.get('items')
        else:
            xbmc.log("BBC News Live: Cache expired.", level=xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f"BBC News Live: Error loading cache: {e}", level=xbmc.LOGERROR)
    return None

def save_cache(items: List[dict]):
    """Saves stream items to the cache file with an expiry timestamp."""
    ensure_addon_data_dir()
    cache_content = {
        'expires_at': time.time() + CACHE_DURATION,
        'items': items
    }
    try:
        with open(CACHE_FILE, 'w') as f:
            json.dump(cache_content, f)
        xbmc.log("BBC News Live: Stream list cached.", level=xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f"BBC News Live: Error saving cache: {e}", level=xbmc.LOGERROR)

# --- Functions from the original script, adapted for Kodi ---

def get_stream_urls_from_vpid(vpid: str, session: requests.Session) -> List[str]:
    """
    Fetches media playlist information for a given VPID and returns stream URLs.
    No print statements, uses xbmc.log for debugging.
    """
    if not vpid:
        return []

    mediaselector_url = f"https://open.live.bbc.co.uk/mediaselector/6/select/version/2.0/mediaset/pc/vpid/{vpid}"
    xbmc.log(f"BBC News Live: Fetching mediaselector URL: {mediaselector_url}", level=xbmc.LOGDEBUG)

    try:
        media_response = session.get(mediaselector_url)
        media_response.raise_for_status()
        media_data = media_response.json()

        stream_urls = []
        if 'media' in media_data:
            for media_item in media_data['media']:
                if 'connection' in media_item:
                    for connection in media_item['connection']:
                        stream_urls.append(connection['href'])
        
        xbmc.log(f"BBC News Live: Found {len(stream_urls)} stream URL(s) for VPID {vpid}.", level=xbmc.LOGDEBUG)
        return stream_urls
    except requests.HTTPError as e:
        xbmc.log(f"BBC News Live: HTTP Error fetching media data for VPID {vpid}: {e}", level=xbmc.LOGERROR)
    except json.JSONDecodeError as e:
        xbmc.log(f"BBC News Live: Error decoding JSON for VPID {vpid}: {e}", level=xbmc.LOGERROR)
    return []

def get_vpid_from_next_data(soup: BeautifulSoup) -> Optional[str]:
    """
    Finds and parses the __NEXT_DATA__ script tag to extract the VPID.
    """
    next_data_script = soup.find('script', id='__NEXT_DATA__')
    if not next_data_script:
        return None

    try:
        data = json.loads(next_data_script.string)
        page_props = data.get('props', {}).get('pageProps', {})
        
        vpid = page_props.get('worldNewsTvScheduleId')
        if vpid:
            return vpid
        
        if 'initialData' in page_props:
            for key, value in page_props['initialData'].get('data', {}).items():
                if key.startswith('live-header'):
                    media_header = value.get('data', {}).get('mediaHeaderData', {})
                    if media_header and media_header.get('liveMediaItems'):
                        version = media_header['liveMediaItems'][0].get('version')
                        if version and 'vpid' in version:
                            return version['vpid']
    except json.JSONDecodeError:
        return None
    return None

def get_vpid_from_initial_data(soup: BeautifulSoup) -> Optional[str]:
    """
    Finds and parses the window.__INITIAL_DATA__ script tag as a fallback.
    """
    script_tag = soup.find('script', string=re.compile(r'window\.__INITIAL_DATA__'))
    if not script_tag:
        return None

    json_match = re.search(r'window\.__INITIAL_DATA__\s*=\s*(".*");', script_tag.string)
    if not json_match:
        return None

    try:
        initial_data_str = json.loads(json_match.group(1))
        initial_data = json.loads(initial_data_str)
        
        for key, value in initial_data.get('data', {}).items():
             if key.startswith('live-header'):
                media_header = value.get('data', {}).get('mediaHeaderData', {})
                if media_header and media_header.get('liveMediaItems'):
                    version = media_header['liveMediaItems'][0].get('version')
                    if version and 'vpid' in version:
                        return version['vpid']
    except (json.JSONDecodeError, KeyError, IndexError):
        return None
    return None

def get_live_events(session: requests.Session) -> List[dict]:
    """
    Scrapes the BBC Live page for currently-live events.
    """
    bbc_live_url = "https://www.bbc.com/live"
    live_events = []
    
    xbmc.log(f"BBC News Live: Fetching main live page: {bbc_live_url}", level=xbmc.LOGDEBUG)
    try:
        main_response = session.get(bbc_live_url)
        main_response.raise_for_status()
        main_soup = BeautifulSoup(main_response.text, 'html.parser')

        live_items_container = main_soup.find('div', attrs={'data-testid': 'tennessee-nowLiveItems'})
        if not live_items_container:
            xbmc.log("BBC News Live: Could not find the 'Live Now' items container.", level=xbmc.LOGWARNING)
            return []

        unique_urls = set()
        for link in live_items_container.find_all('a', href=True):
            event_page_url = link['href']
            # if event_page_url in unique_urls or not event_page_url.startswith('/live/'):
            if event_page_url in unique_urls:
                continue
            unique_urls.add(event_page_url)

            if not event_page_url.startswith('http'):
                event_page_url = "https://www.bbc.com" + event_page_url

            title_tag = link.find('h2', attrs={'data-testid': 'glastonbury-title'})
            title = title_tag.get_text(strip=True) if title_tag else "Untitled Event"
            
            xbmc.log(f"BBC News Live: Processing event: '{title}'", level=xbmc.LOGDEBUG)

            try:
                event_response = session.get(event_page_url)
                event_response.raise_for_status()
                event_soup = BeautifulSoup(event_response.text, 'html.parser')

                vpid = get_vpid_from_next_data(event_soup) or get_vpid_from_initial_data(event_soup)

                if vpid:
                    stream_urls = get_stream_urls_from_vpid(vpid, session)
                    if stream_urls:
                        live_events.append({
                            "title": title,
                            "stream_urls": stream_urls
                        })
                else:
                    xbmc.log(f"BBC News Live: No VPID found for '{title}'. Skipping.", level=xbmc.LOGDEBUG)

            except requests.HTTPError as e:
                xbmc.log(f"BBC News Live: HTTP Error fetching event page '{title}': {e}", level=xbmc.LOGERROR)

    except requests.HTTPError as e:
        xbmc.log(f"BBC News Live: HTTP Error fetching main live page: {e}", level=xbmc.LOGERROR)
    
    return live_events

def get_news_channel_stream(session: requests.Session) -> Optional[dict]:
    """
    Fetches the stream for the main BBC News Channel.
    """
    page_url = "https://www.bbc.com/watch-live-news"
    xbmc.log("BBC News Live: Processing event: 'BBC News Channel'", level=xbmc.LOGDEBUG)

    try:
        response = session.get(page_url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        
        vpid = get_vpid_from_next_data(soup)

        if vpid:
            stream_urls = get_stream_urls_from_vpid(vpid, session)
            if stream_urls:
                return {
                    "title": "BBC News Channel",
                    "stream_urls": stream_urls
                }
        else:
            xbmc.log("BBC News Live: Could not extract VPID for the News Channel.", level=xbmc.LOGERROR)

    except requests.exceptions.RequestException as e:
        xbmc.log(f"BBC News Live: Network request error for News Channel: {e}", level=xbmc.LOGERROR)
    
    return None

def select_stream_url(
    stream_urls: List[str], 
    protocol: str, 
    cdn: str, 
    playlist_format: str
) -> Optional[str]:
    """
    Selects the best stream URL based on addon settings.
    """
    candidates = [
        url for url in stream_urls
        if (url.endswith(f'.{playlist_format}') or ('.m3u8' in url or '.mpd' in url)) and '$' not in url
    ]

    if not candidates:
        return None

    best_url = None
    highest_score = -1

    for url in candidates:
        score = 0
        
        if url.endswith(f'.{playlist_format}'):
            score += 4
        
        if cdn and cdn in url:
            score += 2
        elif 'bbc' in url.split('/')[2]:
            score -= 1
            
        if url.startswith(protocol + '://'):
            score += 1

        if score > highest_score:
            highest_score = score
            best_url = url
    
    return best_url or candidates[0]

# --- Kodi Plugin Main Logic ---

def list_streams():
    """Main function to build the list of playable streams."""
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "BBC News Live")
    xbmcplugin.setContent(ADDON_HANDLE, "videos")

    # Get settings
    protocol = ADDON.getSetting('protocol')
    cdn = ADDON.getSetting('cdn')
    playlist_format = ADDON.getSetting('playlist_format')
    xbmc.log(f"BBC News Live: Settings - Protocol={protocol}, CDN={cdn}, Format={playlist_format}", level=xbmc.LOGDEBUG)

    # Try to load from cache first
    all_items = load_cache()
    
    if all_items is None:
        # Cache miss or expired - fetch fresh data
        xbmc.log("BBC News Live: Cache miss or expired, fetching fresh data.", level=xbmc.LOGDEBUG)
        
        # Use a session for requests
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15'
        })

        # Fetch all events and the news channel
        all_items = get_live_events(session)
        news_channel = get_news_channel_stream(session)
        if news_channel:
            all_items.append(news_channel)
        
        # Save to cache if we got data
        if all_items:
            save_cache(all_items)
    
    if not all_items:
        xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), "No live video streams found at this time.")
        xbmcplugin.endOfDirectory(handle=ADDON_HANDLE, succeeded=False, cacheToDisc=False)
        return

    # Create list items for Kodi
    for item in all_items:
        best_url = select_stream_url(item['stream_urls'], protocol, cdn, playlist_format)
        
        if not best_url:
            continue
        
        list_item = xbmcgui.ListItem(label=item['title'])
        list_item.getVideoInfoTag().setTitle(item['title'])
        list_item.getVideoInfoTag().setMediaType('video')
        list_item.setProperty('IsPlayable', 'true')
        
        # Add context menu item to open settings
        list_item.addContextMenuItems([('Add-on Settings', f'Addon.OpenSettings({ADDON.getAddonInfo("id")})')])

        url = f"{ADDON_URL}?action=play&stream_url={best_url}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(handle=ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def play_stream(url):
    """Resolves a URL to be played by Kodi."""
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=True, listitem=play_item)

def router(paramstring):
    """Simple router"""
    params = dict(parse_qs(paramstring[1:]))
    action = params.get('action', [None])[0]

    if action == 'play':
        play_stream(params['stream_url'][0])
    else:
        list_streams()

if __name__ == '__main__':
    router(sys.argv[2])